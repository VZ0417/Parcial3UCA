const mongoose = require('mongoose');
const { Schema } = mongoose;

const LabSchema = new Schema({
  nombre: {
    type: String,
    required: true
  },
  edificio: {
    type: String,
    required: true
  },
  capacidad: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
});

module.exports = mongoose.model('Lab', LabSchema);