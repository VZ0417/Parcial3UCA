const express = require('express');
const router = express.Router();

// Models
const Lab = require('../models/Lab');

// Helpers
const { isAuthenticated } = require('../helpers/auth');

// Nueva reserva
router.get('/labs/add', isAuthenticated, (req, res) => {
  res.render('labs/new-lab');
});

router.post('/labs/new-lab', isAuthenticated, async (req, res) => {
  const {nombre, edificio, capacidad} = req.body;
  const errors = [];
  if (!nombre) {
    errors.push({text: 'Por favor, digite el nombre del laboratorio.'});
  }
  if (!edificio) {
    errors.push({text: 'Por favor, digite el edificio.'});
  }
  if (!capacidad) {
    errors.push({text: 'Por favor, indique la capacidad del laboratorio.'});
  }
  if (errors.length > 0) {
    res.render('labs/new-lab', {
      errors,
      nombre,
      edificio,
      capacidad
    });
  } else {
    const newLab = new Lab({nombre, edificio, capacidad});
    newLab.user = req.user.id;
    await newLab.save();
    req.flash('success_msg', 'Laboratorio registrado con éxito');
    res.redirect('/labs');
  }
});

// Get de todas las solicitudes
router.get('/labs', isAuthenticated, async (req, res) => {
  const labs = await Lab.find({user: req.user.id}).sort({date: 'desc'});
  res.render('labs/all-labs', { labs });
});

// Editar solicitudes
router.get('/labs/edit/:id', isAuthenticated, async (req, res) => {
  const lab = await Lab.findById(req.params.id);
  if(lab.user != req.user.id) {
    req.flash('error_msg', 'No autorizado');
    return res.redirect('/labs');
  } 
  res.render('labs/edit-lab', { lab });
});

router.put('/labs/edit-lab/:id', isAuthenticated, async (req, res) => {
  const {nombre, edificio, capacidad} = req.body;
  await Lab.findByIdAndUpdate(req.params.id, {nombre, edificio, capacidad});
  req.flash('success_msg', 'Solicitud modificada con éxito');
  res.redirect('/labs');
});

// Delete de solicitudes
router.delete('/labs/delete/:id', isAuthenticated, async (req, res) => {
  await Lab.findByIdAndDelete(req.params.id);
  req.flash('success_msg', 'Laboratorio borradado con éxito');
  res.redirect('/labs');
});

module.exports = router;